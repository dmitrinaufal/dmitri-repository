package com.codesimple.bookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarterApp {

    public static void main(String[] args){
        SpringApplication.run(StarterApp.class, args);
    }
}
