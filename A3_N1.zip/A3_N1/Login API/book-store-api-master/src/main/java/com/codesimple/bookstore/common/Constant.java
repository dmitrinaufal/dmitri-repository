package com.codesimple.bookstore.common;

public interface Constant {

    interface USER_TYPE{
        String NORMAL = "NORMAL";
        String ADMIN = "ADMIN";
    }
}
