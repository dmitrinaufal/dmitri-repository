function fetchStudentData() {
    fetch('http://localhost:9696/persons')
    .then(response => response.json())
    .then(data => {
        console.log('Data fetched successfully', data);
        const mahasiswaTableBody = document.getElementById('mahasiswaTableBody');
        data.forEach(mahasiswa => {
            console.log (mahasiswa.id, mahasiswa.name)
        })
        data.forEach(mahasiswa => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${mahasiswa.id}</td>
                <td>${mahasiswa.name}</td>
                
            `;
            mahasiswaTableBody.appendChild(row);
        });
    })
    .catch(error => {
        console.error('Error to fetching data:', error);
    });
}