import TableComponent from './TableComponent';


function App() {
    return (
      <div className="App">
        <TableComponent />
      </div>
    );
  }

export default TableComponent