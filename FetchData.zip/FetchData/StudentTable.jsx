// src/components/TableComponent.js
import React, { Component } from 'react';
import axios from 'axios';

class StudentTable extends Component {
  state = {
    data: [],
  };

  componentDidMount() {
    axios.get('http://localhost:9696/persons')
      .then((response) => {
        this.setState({ data: response.data });
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }

  render() {
    return (
      <div>
        <h1>Data Mahasiswa</h1>
        <table>
          {/* Table header */}
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>              
            </tr>
          </thead>
          {/* Table body */}
          <tbody>
            {this.state.data.map((item) => (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.name}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default StudentTable;
