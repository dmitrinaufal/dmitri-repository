import { createProxyMiddleware } from 'http-proxy-middleware';

export default function (app) {
  app.use(
    '/persons',
    createProxyMiddleware({
      target: 'http://localhost:9696',
      changeOrigin: true,
    })
  );
};
